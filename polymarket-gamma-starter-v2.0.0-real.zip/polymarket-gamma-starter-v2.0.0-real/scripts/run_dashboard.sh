#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m uvicorn app.main:app --reload
